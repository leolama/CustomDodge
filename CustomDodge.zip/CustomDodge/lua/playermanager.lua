_G.dodge_change = dodge_change or {}
dodge_change.modpath = ModPath
dodge_change.savepath = SavePath .. "custom_dodge.txt"
dodge_change.settings = {
  dodge_change_choice = 1,
}

function PlayerManager:skill_dodge_chance(running, crouching, on_zipline, override_armor, detection_risk)
  if dodge_change.settings.dodge_change_choice == 1 then
    return 0
  elseif dodge_change.settings.dodge_change_choice == 2 then
    return -1000
  else
    return 1000
  end
end

Hooks:Add("LocalizationManagerPostInit", "dodge_changelocalizationmod_loadlocalization", function(localizationmanager)

	dodge_change:Load()

	localizationmanager:add_localized_strings({
      dodge_change_options_title = "Custom Dodge",
      dodge_change_options_desc = "Change your dodge options",
      dodge_change_choice_title = "Dodge",
      dodge_change_choice_desc = "Change your dodge options",
      dodge_change_no_change = "No change",
      dodge_change_loads = "High dodge",
      dodge_change_none = "Negative dodge"
	})
end)

function dodge_change:Load()
	local file = io.open(self.savepath, "r")
	if (file) then
		for k, v in pairs(json.decode(file:read("*all"))) do
			self.settings[k] = v
		end
	else
		self:Save() --create data in case there's no mod save data
	end
	return self.settings
end

function dodge_change:Save()
	local file = io.open(self.savepath,"w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

Hooks:Add("MenuManagerInitialize", "dodge_change_createmenu", function(menu_manager)

	MenuCallbackHandler.callback_dodge_change_choice = function(self,item)
    	dodge_change.settings.dodge_change_choice = tonumber(item:value())
		dodge_change:Save()
	end

	MenuHelper:LoadFromJsonFile(dodge_change.modpath .. "/menu/options.json", dodge_change, dodge_change.settings)

end)